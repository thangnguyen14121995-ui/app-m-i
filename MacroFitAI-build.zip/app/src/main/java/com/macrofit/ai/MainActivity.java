package com.macrofit.ai;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Native Android shell backed by standard Android SDK APIs.
 * No handcrafted DEX, no runtime app install, no arbitrary file URLs.
 * Gallery = ACTION_OPEN_DOCUMENT. Camera = ACTION_IMAGE_CAPTURE + MediaStore URI.
 */
public final class MainActivity extends Activity {
    private static final String TAG = "MacroFit";
    private static final String APP_ORIGIN = "appassets.androidplatform.net";
    private static final String HOME = "https://" + APP_ORIGIN + "/assets/index.html";
    private static final int PICK_FILE = 4101;
    private static final int TAKE_PICTURE = 4102;
    private static final int SAVE_BACKUP = 4103;
    private static final int MAX_BACKUP_CHARS = 3_000_000;

    private WebView web;
    private ValueCallback<Uri[]> pendingChooser;
    private Uri pendingCamera;
    private String pendingExport;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(11, 17, 29));
        getWindow().setNavigationBarColor(Color.rgb(11, 17, 29));
        if (state != null) {
            String saved = state.getString("camera_uri");
            if (saved != null && !saved.isEmpty()) pendingCamera = Uri.parse(saved);
        }
        try {
            setupWebView();
        } catch (Throwable e) {
            Log.e(TAG, "Startup failure", e);
            showStartupError("Không thể mở giao diện. Thử cập nhật Android System WebView.");
        }
    }

    private void setupWebView() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(11, 17, 29));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setDefaultTextEncodingName("UTF-8");
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        web.addJavascriptInterface(new AndroidBackup(), "MacroFitAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !APP_ORIGIN.equals(uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null || !path.startsWith("/assets/")) return notFound();
                String fileName = path.substring("/assets/".length());
                // Whitelist exact resources, no directory traversal or arbitrary file reads.
                if (!fileName.equals("index.html") && !fileName.equals("icon.svg")
                        && !fileName.equals("manifest.webmanifest")) return notFound();
                String type = fileName.endsWith(".svg") ? "image/svg+xml"
                        : fileName.endsWith(".webmanifest") ? "application/manifest+json" : "text/html";
                try {
                    InputStream stream = getAssets().open(fileName);
                    WebResourceResponse response = new WebResourceResponse(type, "UTF-8", stream);
                    return response;
                } catch (IOException e) {
                    Log.e(TAG, "Missing asset: " + fileName, e);
                    return notFound();
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equals(url.getScheme()) && APP_ORIGIN.equals(url.getHost())) return false;
                if (!request.isForMainFrame()) return false;
                String scheme = url.getScheme();
                if ("https".equals(scheme) || "http".equals(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, url)); }
                    catch (Exception e) { shortToast("Không mở được liên kết"); }
                }
                return true;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                                                    android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {
                    Log.e(TAG, "WebView load failed: " + error.getDescription());
                    showStartupError("Không tải được giao diện ứng dụng.");
                }
            }
            @Override public boolean onRenderProcessGone(WebView view,
                                              android.webkit.RenderProcessGoneDetail detail) {
                Log.e(TAG, "WebView render process ended. crashed=" + detail.didCrash());
                if (web != null) {
                    WebView crashed = web;
                    web = null;
                    if (crashed.getParent() instanceof ViewGroup) {
                        ((ViewGroup) crashed.getParent()).removeView(crashed);
                    }
                    crashed.destroy();
                }
                showStartupError("Android WebView vừa gặp lỗi. Nhấn thử lại để mở lại.");
                return true; // Keep Activity alive even if WebView renderer crashes.
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                       ValueCallback<Uri[]> callback, FileChooserParams params) {
                // Always complete any previous callback; otherwise Android may lock file input.
                releaseChooser(null);
                pendingChooser = callback;
                boolean camera = params != null && params.isCaptureEnabled()
                        && acceptsImage(params.getAcceptTypes());
                if (camera) launchCamera();
                else launchDocumentPicker(chooseMime(params));
                return true;
            }
            @Override public boolean onConsoleMessage(ConsoleMessage msg) {
                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "JS " + msg.messageLevel() + " " + msg.sourceId()
                            + ":" + msg.lineNumber() + " " + msg.message());
                }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl(HOME);
    }

    private WebResourceResponse notFound() {
        WebResourceResponse response = new WebResourceResponse("text/plain", "UTF-8",
                new ByteArrayInputStream("Not found".getBytes(StandardCharsets.UTF_8)));
        response.setStatusCodeAndReasonPhrase(404, "Not Found");
        return response;
    }

    private static boolean acceptsImage(String[] accept) {
        if (accept == null) return true;
        for (String s : accept) {
            if (s != null && (s.contains("image") || s.equals("*/*"))) return true;
        }
        return false;
    }

    private static String chooseMime(WebChromeClient.FileChooserParams params) {
        if (params == null) return "*/*";
        String[] types = params.getAcceptTypes();
        if (types == null || types.length == 0) return "*/*";
        for (String type : types) {
            if (type == null) continue;
            String t = type.toLowerCase(Locale.ROOT);
            if (t.startsWith("image/")) return "image/*";
            if (t.contains("json")) return "application/json";
        }
        return "*/*";
    }

    private void launchDocumentPicker(String mime) {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType(mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, PICK_FILE);
        } catch (Exception e) {
            Log.e(TAG, "Gallery/document picker failed", e);
            releaseChooser(null);
            shortToast("Không mở được Thư viện. Thử lại hoặc cập nhật ứng dụng Tệp.");
        }
    }

    private void launchCamera() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,
                    "macrofit-" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/MacroFit");
            pendingCamera = getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingCamera == null) throw new IOException("MediaStore returned null");
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCamera);
            intent.setClipData(ClipData.newUri(getContentResolver(), "meal", pendingCamera));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, TAKE_PICTURE);
        } catch (Exception e) {
            Log.e(TAG, "Camera failed", e);
            discardCamera();
            releaseChooser(null);
            shortToast("Không mở được Camera. Hãy thử chọn ảnh từ Thư viện.");
        }
    }

    private void releaseChooser(Uri[] result) {
        ValueCallback<Uri[]> callback = pendingChooser;
        pendingChooser = null;
        if (callback != null) {
            try { callback.onReceiveValue(result); }
            catch (Exception e) { Log.w(TAG, "File callback failed", e); }
        }
    }

    private void discardCamera() {
        if (pendingCamera != null) {
            try { getContentResolver().delete(pendingCamera, null, null); }
            catch (Exception ignored) { }
            pendingCamera = null;
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == PICK_FILE) {
            releaseChooser(WebChromeClient.FileChooserParams.parseResult(result, data));
        } else if (request == TAKE_PICTURE) {
            if (result == RESULT_OK && pendingCamera != null) {
                releaseChooser(new Uri[]{pendingCamera});
                pendingCamera = null;
            } else {
                releaseChooser(null);
                discardCamera();
            }
        } else if (request == SAVE_BACKUP) {
            if (result == RESULT_OK && data != null && data.getData() != null
                    && pendingExport != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(data.getData())) {
                    if (stream == null) throw new IOException("Could not open output file");
                    stream.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    shortToast("Đã lưu bản sao nhật ký ✓");
                } catch (Exception e) {
                    Log.e(TAG, "Backup export failed", e);
                    shortToast("Không lưu được. Thử lại với thư mục khác.");
                }
            }
            pendingExport = null;
        }
    }

    private final class AndroidBackup {
        @JavascriptInterface public void saveBackup(String json) {
            if (json == null || json.isEmpty() || json.length() > MAX_BACKUP_CHARS) {
                runOnUiThread(() -> shortToast("Bản sao lưu trống hoặc quá lớn."));
                return;
            }
            runOnUiThread(() -> {
                pendingExport = json;
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE,
                            "macrofit-backup-" + System.currentTimeMillis() + ".json");
                    startActivityForResult(intent, SAVE_BACKUP);
                } catch (Exception e) {
                    pendingExport = null;
                    Log.e(TAG, "Export chooser failed", e);
                    shortToast("Không mở được hộp thoại lưu tệp.");
                }
            });
        }
    }

    private void showStartupError(String message) {
        FrameLayout layout = new FrameLayout(this);
        layout.setBackgroundColor(Color.rgb(11, 17, 29));
        TextView text = new TextView(this);
        text.setText(message + "\n\nChạm để thử mở lại.");
        text.setTextColor(Color.WHITE);
        text.setTextSize(18);
        text.setPadding(36, 90, 36, 36);
        layout.addView(text);
        layout.setOnClickListener(v -> {
            if (web != null) {
                web.destroy(); web = null;
            }
            try { setupWebView(); }
            catch (Exception e) { Log.e(TAG, "Retry failed", e); shortToast("Không thể khởi động."); }
        });
        setContentView(layout);
    }

    private void shortToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override protected void onSaveInstanceState(Bundle state) {
        if (pendingCamera != null) state.putString("camera_uri", pendingCamera.toString());
        super.onSaveInstanceState(state);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        releaseChooser(null);
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
